# 🚀 Hosting CRM - سیستم مدیریت هاستینگ

## نصب سریع (۵ دقیقه)

### ۱. Extract کن و وارد پوشه شو
```bash
cd hosting-crm
```

### ۲. وابستگی‌های PHP رو نصب کن
```bash
composer install
```

### ۳. تنظیمات محیطی
```bash
cp .env.example .env
php artisan key:generate
```

### ۴. دیتابیس بساز
در MySQL یک دیتابیس بساز:
```sql
CREATE DATABASE hosting_crm CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### ۵. فایل `.env` رو ویرایش کن
```env
DB_DATABASE=hosting_crm
DB_USERNAME=root
DB_PASSWORD=رمز_دیتابیس
```

### ۶. جداول رو بساز
```bash
php artisan migrate
php artisan db:seed
```

### ۷. فرانت رو نصب کن
```bash
npm install
npm run build
```

### ۸. اجرا کن
```bash
php artisan serve
```

### ۹. وارد شو
برو به: http://localhost:8000

**موبایل:** `09123456789`

در حالت development، کد OTP در کنسول لاراول (storage/logs/laravel.log) نمایش داده میشه.

---

## امکانات فاز ۱ ✅

- [x] احراز هویت با موبایل و OTP
- [x] سیستم پیامک کاوه‌نگار
- [x] مدیریت پرسنل با نقش‌ها
- [x] سیستم دسترسی (Permission)
- [x] قالب فارسی RTL

## فازهای بعدی 🚧

- [ ] فاز ۲: مدیریت مشتریان + کیف پول
- [ ] فاز ۳: محصولات و قیمت‌گذاری
- [ ] فاز ۴: فاکتور و درگاه پرداخت
- [ ] فاز ۵: تیکتینگ
- [ ] فاز ۶: مدیریت سرویس‌ها
- [ ] فاز ۷: اتصال به WHM/cPanel

---

## ساختار پوشه‌ها

```
hosting-crm/
├── app/
│   ├── Models/User.php
│   └── Http/Middleware/
├── Modules/
│   ├── Core/          # احراز هویت، داشبورد
│   ├── SMS/           # کاوه‌نگار
│   └── Staff/         # مدیریت پرسنل
├── resources/views/
├── routes/web.php
└── database/
```

## سوال داری؟

ادامه بده و فاز بعدی رو بخواه! 🎉
