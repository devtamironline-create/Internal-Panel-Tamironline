<?php
/**
 * Tamironline Panel - Installation Script
 * Run this once after uploading files
 */

echo "<html dir='rtl'><head><meta charset='UTF-8'><title>نصب پنل تعمیرآنلاین</title>";
echo "<style>body{font-family:Tahoma,sans-serif;padding:40px;background:#f5f5f5;}";
echo ".box{background:#fff;padding:30px;border-radius:10px;max-width:600px;margin:auto;box-shadow:0 2px 10px rgba(0,0,0,0.1);}";
echo "h1{color:#1a2d48;}.ok{color:green;}.err{color:red;}pre{background:#f0f0f0;padding:15px;border-radius:5px;}</style></head><body>";
echo "<div class='box'>";
echo "<h1>🔧 نصب پنل تعمیرآنلاین</h1>";

$errors = [];

// Check PHP version
if (version_compare(PHP_VERSION, '8.2.0', '<')) {
    $errors[] = "PHP 8.2+ نیاز است. نسخه فعلی: " . PHP_VERSION;
}

// Check required extensions
$required = ['pdo_mysql', 'mbstring', 'openssl', 'tokenizer', 'xml', 'ctype', 'json', 'bcmath'];
foreach ($required as $ext) {
    if (!extension_loaded($ext)) {
        $errors[] = "افزونه $ext نصب نیست";
    }
}

// Check GD or Imagick
if (!extension_loaded('gd') && !extension_loaded('imagick')) {
    $errors[] = "GD یا Imagick نیاز است";
}

if ($errors) {
    echo "<h2 class='err'>❌ خطاها:</h2><ul>";
    foreach ($errors as $e) echo "<li class='err'>$e</li>";
    echo "</ul></div></body></html>";
    exit;
}

echo "<p class='ok'>✅ PHP " . PHP_VERSION . " - OK</p>";
echo "<p class='ok'>✅ همه افزونه‌ها نصب هستند</p>";

// Create directories
$dirs = [
    '../storage/framework/sessions',
    '../storage/framework/views', 
    '../storage/framework/cache/data',
    '../storage/logs',
    '../bootstrap/cache'
];

foreach ($dirs as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
}
echo "<p class='ok'>✅ پوشه‌ها ایجاد شدند</p>";

// Check .env
if (!file_exists('../.env')) {
    if (file_exists('../.env.example')) {
        copy('../.env.example', '../.env');
        echo "<p class='ok'>✅ فایل .env ایجاد شد</p>";
    }
} else {
    echo "<p class='ok'>✅ فایل .env موجود است</p>";
}

echo "<hr>";
echo "<h2>📋 مراحل بعدی:</h2>";
echo "<pre>";
echo "1. فایل .env را ویرایش کنید:\n";
echo "   - APP_URL=https://your-domain.com\n";
echo "   - DB_HOST=localhost\n";
echo "   - DB_DATABASE=نام_دیتابیس\n";
echo "   - DB_USERNAME=نام_کاربری\n";
echo "   - DB_PASSWORD=رمز_عبور\n\n";
echo "2. در ترمینال SSH اجرا کنید:\n";
echo "   cd /home/YOUR_USER/public_html\n";
echo "   php artisan key:generate\n";
echo "   php artisan migrate --seed\n\n";
echo "3. این فایل install.php را حذف کنید\n";
echo "</pre>";
echo "<p style='color:orange;'><strong>⚠️ مهم:</strong> بعد از اتمام نصب، این فایل را حذف کنید!</p>";
echo "</div></body></html>";
?>
