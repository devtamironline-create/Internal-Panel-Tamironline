<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\OKR\\Providers\\OKRServiceProvider',
    1 => 'Modules\\Salary\\Providers\\SalaryServiceProvider',
    2 => 'Modules\\Task\\Providers\\TaskServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\OKR\\Providers\\OKRServiceProvider',
    1 => 'Modules\\Salary\\Providers\\SalaryServiceProvider',
    2 => 'Modules\\Task\\Providers\\TaskServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);