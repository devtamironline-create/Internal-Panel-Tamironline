<?php

return [
    App\Providers\AppServiceProvider::class,
    Modules\Core\Providers\CoreServiceProvider::class,
    Modules\SMS\Providers\SMSServiceProvider::class,
    Modules\Attendance\Providers\AttendanceServiceProvider::class,
];
